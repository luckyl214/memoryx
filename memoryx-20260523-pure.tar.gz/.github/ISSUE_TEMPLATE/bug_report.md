---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. ...

**Expected behavior**
A clear description of what you expected to happen.

**Environment**
- Python version:
- memoryx version:
- OS:

**Additional context**
Add any other context about the problem here.
